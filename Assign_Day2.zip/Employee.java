package com.company;

public class Employee {

    String name;
    int age;
    String city;

    public void display() {

        System.out.println();
        System.out.println("Employee name is: "+name);
        System.out.println("Age is: "+age);
        System.out.println("City is: "+city);
    }
}
