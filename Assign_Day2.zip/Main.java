package com.company;

public class Main {

    public static void main(String[] args) {

        Employee e1= new Employee();
        Employee e2 = new Employee();

        e1.name="Employee1";
        e1.age=20;
        e1.city="Delhi";

        e2.name="Emolyee2";
        e2.age=21;
        e2.city="Mumbai";

        e1.display();
        e2.display();
    }
}
